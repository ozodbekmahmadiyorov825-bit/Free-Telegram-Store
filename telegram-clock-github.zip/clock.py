import os
from datetime import datetime
from zoneinfo import ZoneInfo
from telethon import TelegramClient

API_ID = int(os.environ["API_ID"])
API_HASH = os.environ["API_HASH"]
SESSION = os.environ["SESSION"]
TZ = os.getenv("TZ", "Asia/Tashkent")

client = TelegramClient("clock", API_ID, API_HASH)

async def main():
    now = datetime.now(ZoneInfo(TZ))
    clock = now.strftime("%H:%M")
    # Only change the profile first name. Bio and profile photo are untouched.
    me = await client.get_me()
    current_last = me.last_name or ""
    await client(functions.account.UpdateProfileRequest(
        first_name=clock,
        last_name=current_last
    ))

with client:
    from telethon import functions
    client.loop.run_until_complete(main())
